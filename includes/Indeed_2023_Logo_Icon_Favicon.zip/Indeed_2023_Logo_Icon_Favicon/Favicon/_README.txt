Indeed Favicon README

Reference this article for suggested implementation:

https://evilmartians.com/chronicles/how-to-favicon-in-2021-six-files-that-fit-most-needs

                                                    
                                   %%%%%%%%%%%%%%%%%                  
                               %%%%%%             #%%%%                 
                           *%%%%                       %%                 
                         %%%#                                              
                       %%%            %%%%%%                                
                     .%%           %%%%%%%%%%%%                               
                    %%            %%%%%%%%%%%%%%                               
                   %%            %%%%%%%%%%%%%%%                               
                  %%              %%%%%%%%%%%%%                                 
                  %                 %%%%%%%%%                                   
                 %                                                              
                                                                             
                                    %%%%%%%%%%                                  
                                    %%%%%%%%%%                                  
                                    %%%%%%%%%%                                  
                                    %%%%%%%%%%                                 
                                    %%%%%%%%%%                                 
                                    %%%%%%%%%%                                
                                    %%%%%%%%%%                              
                                    %%%%%%%%%%                             
                                    %%%%%%%%%%                            
                                    %%%%%%%%%%                          
                                     %%%%%%%%                        



